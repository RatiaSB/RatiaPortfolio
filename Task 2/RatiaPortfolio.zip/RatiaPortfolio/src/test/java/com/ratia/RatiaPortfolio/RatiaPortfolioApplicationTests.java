package com.ratia.RatiaPortfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatiaPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
